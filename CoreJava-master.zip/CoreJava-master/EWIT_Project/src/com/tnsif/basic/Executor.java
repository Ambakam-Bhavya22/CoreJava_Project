package com.tnsif.interfaces;

public class Executor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SampleInterface1 obj;
				Derived d=new Derived();
				d.display();
			}
		}

	
