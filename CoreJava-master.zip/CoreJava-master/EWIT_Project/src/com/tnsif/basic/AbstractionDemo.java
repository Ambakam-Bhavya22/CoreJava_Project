package com.tnsif.Abstraction;

public abstract class AbstractionDemo {
AbstractionDemo(){
		
	}
	void m1() {
	
	}
	abstract void m2();
}


