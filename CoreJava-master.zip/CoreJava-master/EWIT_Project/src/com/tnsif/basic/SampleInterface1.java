package com.tnsif.interfaces;

public interface SampleInterface1 {
	int a=10;
	default void display() {
	}
	default void show() {
	}
	
		
	
}





