package com.tns.collections.List;
import java.util.Deque;
import java.util.Stack;
import java.util.Vector;
public class StackDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack s=new Stack();
		s.push(10);
		s.push(20);
		System.out.println(s);
		s.pop();
		System.out.println(s);
	}


	}


