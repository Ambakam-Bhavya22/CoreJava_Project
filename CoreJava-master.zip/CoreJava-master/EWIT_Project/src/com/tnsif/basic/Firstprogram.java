package com.tnsif.basic;

public class Firstprogram {

	public static void main(String[] args) {
		System.out.println("Hello,World");

	}

}
