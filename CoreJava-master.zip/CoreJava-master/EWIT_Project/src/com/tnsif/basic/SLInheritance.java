package com.tnsif.SLInheritance;

public class SLInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student obj = new Student("Ankita","0123","Bengaluru",1234L,123,"EWIT");
		System.out.println(obj);

	}

}
