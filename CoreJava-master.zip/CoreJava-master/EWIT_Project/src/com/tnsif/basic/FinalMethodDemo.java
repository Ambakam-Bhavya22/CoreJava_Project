package com.tnsif.FinalDemo;

public class FinalMethodDemo extends FinalMethodClass {
	
	@Override
	void display() {
		
	}
	
	//Final methods can not be overrided
	/*
	 * @Override void show() { }
	 */
}


