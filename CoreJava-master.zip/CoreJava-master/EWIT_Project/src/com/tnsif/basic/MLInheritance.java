package com.tnsif.MLInheritance;

public class MLInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
