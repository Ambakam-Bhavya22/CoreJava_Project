package com.tnsif.ExceptionHandling;

public class WithoutExceptionHandling {

	public static void main(String[] args) {
		// //int data = 10/0;
	}


	}


