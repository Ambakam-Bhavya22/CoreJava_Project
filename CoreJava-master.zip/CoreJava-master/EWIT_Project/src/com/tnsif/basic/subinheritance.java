package com.tnsif.inheritance;

public class subinheritance {

}
