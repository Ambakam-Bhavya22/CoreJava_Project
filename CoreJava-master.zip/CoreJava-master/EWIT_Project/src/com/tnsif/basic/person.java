package com.tnsif.firstpackage;

public class person {
	private String personName="ankita";
	private int personAge=20;
	private String personCity="bgm";
	public void display() {
		System.out.println(personName + " " + personAge + " " + personCity);
	}
}
