package com.tnsif.firstpackage;

public class Secondprogram {

	public static void main(String[] args) {
		person p=new person();
		p.display();
		

	}

}
