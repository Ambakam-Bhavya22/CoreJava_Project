package com.tnsif.FinalDemo;


	class Demo{
		
	}

	final class FinalClass{
		
	}

	//Final Class can not be inherited
	/*public class FinalClassDemo extends FinalClass{
	public static void main(String args[]) {
		
	}
	}*/


