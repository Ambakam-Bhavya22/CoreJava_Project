package com.tnsif.staticdemo;

public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee("Bob",101);
		Employee e2=new Employee("Alex",102);
		Employee e3=new Employee("Tom",103);
		Employee e4=new Employee("Robert",104);
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		System.out.println(e4);
			
	}


}


