package com.tnsif.interfaces;

public class Derived implements SampleInterface1 {

	@Override
	public void display() {
		System.out.println("Hi");
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
	}


}
